function closedIssuanceProtectedRecordsForRetirement(input: Readonly<{
	objectId: string; throughEpoch: number; rows: IssuanceRetirementRows;
	intent: Readonly<{decisionDigest: string; sourceProofDigest: string}> | undefined;
	control: DurableIssuanceRetirementControl | null; censusRows: unknown;
	protectedReplayScopes: readonly LiveJournalScope[]; physicalJournalRows: readonly Uint8Array[];
	dependenciesClassified: boolean;
}>) {
	const physicalScopes = new Set(input.physicalJournalRows.flatMap(bytes => {
		const frame = decodeCanonical(bytes);
		if (!Array.isArray(frame) || frame[0] !== "acceptedEntries" && frame[0] !== "accepted_entries") return [];
		requireLaw(Array.isArray(frame[1]) && frame[1].length === 4, "chain-invalid");
		return [JSON.stringify(frame[1].slice(0, 3))];
	}));
	const classified = Array.isArray(input.censusRows) ? input.censusRows : [];
	const prior = input.control?.active?.preparation ?? input.control?.completed;
	const same = prior != null && prior.throughEpoch === input.throughEpoch && input.intent !== undefined &&
		prior.decisionDigest === input.intent.decisionDigest && prior.sourceProofDigest === input.intent.sourceProofDigest
		? prior : undefined;
	// The cut is only a monotone frontier, not intent identity. A fresh fully
	// authenticated source after the last journal consumer disappears can release
	// old holes at that same cut. An incomplete intent must still resume exactly.
	requireLaw(input.control?.active == null || same === input.control.active.preparation, "chain-invalid");
	const selected = Object.freeze(input.rows.issued.filter(row => {
		const value = record(row.canonicalPreimageBytes), epoch = value.epoch;
		requireLaw(typeof epoch === "number" && Number.isSafeInteger(epoch) && epoch >= 0, "chain-invalid");
		requireLaw(row.objectId === input.objectId && value.objectId === input.objectId && value.author === row.author &&
			value.authorSequence === row.authorSequence, "chain-invalid");
		if (epoch > input.throughEpoch) return false;
		const digest = Array.from(row.digest, byte => byte.toString(16).padStart(2, "0")).join("");
		const hasHole = (p: NonNullable<DurableIssuanceRetirementControl["completed"]>) => p.protectedRecords.some(
			hole => hole.author === row.author && hole.authorSequence === row.authorSequence && hole.digest === digest);
		if (input.control?.completed != null && epoch <= input.control.completed.throughEpoch && !hasHole(input.control.completed)) return false;
		if (same !== undefined) return hasHole(same);
		if (!input.dependenciesClassified) return true;
		const covered = classified.filter(proof => proof?.scope?.objectId === input.objectId && proof.scope.author === row.author &&
			proof.authorSequence === row.authorSequence &&
			((proof.classification === "covered-historical" || proof.classification === "filtered-settlement-source") &&
				(proof.dependencyKind === "signed-settled-issuance" || proof.dependencyKind === "authenticated-covered-native-issuance") ||
			 proof.classification === "pinned-genesis" && epoch === 0 &&
				(proof.dependencyKind === "pinned-genesis" || proof.dependencyKind === "authenticated-covered-native-issuance")) &&
			proof.digest instanceof Uint8Array && compareBytes(proof.digest, row.digest) === 0);
		const paired = input.rows.outbox.filter(out => out.objectId === input.objectId && out.author === row.author &&
			out.authorSequence === row.authorSequence && out.publishState === "published" && compareBytes(out.digest, row.digest) === 0);
		const retired = epoch <= input.throughEpoch - 2 && covered.length === 1 && paired.length === 1 &&
			!input.protectedReplayScopes.some(scope => scope.objectId === input.objectId && scope.epoch === epoch && scope.anchorDigest === value.anchor) &&
			!physicalScopes.has(JSON.stringify([input.objectId, epoch, value.anchor]));
		return !retired;
	}).map(row => Object.freeze({author: row.author, authorSequence: row.authorSequence,
		digest: Array.from(row.digest, byte => byte.toString(16).padStart(2, "0")).join("")}))
		.sort((a, b) => {
			const left = JSON.stringify([a.author, a.authorSequence, a.digest]), right = JSON.stringify([b.author, b.authorSequence, b.digest]);
			return left < right ? -1 : left > right ? 1 : 0;
		}));
	return closeIssuanceRetirementProtectedRecords({control: input.control, rows: input.rows,
		throughEpoch: input.throughEpoch, protectedRecords: selected});
}

