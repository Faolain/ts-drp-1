import {spawn} from "node:child_process";
import {writeFileSync,readFileSync} from "node:fs";
const root="/private/tmp/ts-drp-track-j-finish", dir="/private/tmp/ts-drp-track-j-extension-apalache";
const cases=[
 ["contract-base","proofContractSafetyReducedA","init","step",0,"indContract","ok"],
 ["decided-base","proofSmallA","init","step",0,"indInv","ok"],
 ["decided-step","proofSmallA","indInit","step",1,"indInv","ok"],
 ["contract-move","proofContractSafetyReducedA","indInitContract","stepMove",1,"indContract","ok"],
 ["contract-seal","proofContractSafetyReducedA","indInitContract","stepSeal",1,"indContract","ok"],
 ["contract-nonvacuity","proofContractSafetyReducedA","indInitContract","step",0,"indRichStateAbsent3","violation"]
];
for(const [name,main,init,step,depth,invariant,expected] of cases){
 const args=["packages/protocol-v3/formal/settlement-replacement-retirement-mutations/run-check.mjs","node_modules/.bin/quint","verify",
 "packages/protocol-v3/formal/settlement-replacement-retirement-proofs.qnt","--main",main,"--backend","apalache","--apalache-version","0.56.1",
 "--server-endpoint","localhost:8843","--apalache-config",dir+"/config.json","--init",init,"--step",step,"--max-steps="+depth,"--invariants",invariant,"--verbosity=3"];
 const buffers=[],started=Date.now(), log=dir+"/"+name+".log";
 const child=spawn("node",args,{cwd:root,env:{...process.env,JAVA_HOME:"/opt/homebrew/opt/openjdk@17",PATH:"/opt/homebrew/opt/openjdk@17/bin:"+process.env.PATH,JVM_ARGS:"-Xmx8g",TRACK_J_TIMEOUT_SECONDS:"900"}});
 for(const stream of[child.stdout,child.stderr])stream.on("data",b=>{buffers.push(b);writeFileSync(log,Buffer.concat(buffers));});
 const code=await new Promise(resolve=>child.on("close",resolve));
 const body=readFileSync(log,"utf8"), got=code===0 && /^\[ok\]/m.test(body)?"ok":code===1 && /^\[violation\]/m.test(body)?"violation":code===124?"timeout":"error";
 console.log(JSON.stringify({name,main,init,step,depth,invariant,expected,got,code,seconds:Math.round((Date.now()-started)/1000),log}));
}
