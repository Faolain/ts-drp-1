import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='/private/tmp/ts-drp-track-j-a5-final';
writeFileSync(dir+'/tlc.json',JSON.stringify({workers:1,maxHeap:'-Xmx2G'}));
for(const main of ['exhContractSafetyA5','exhContractProgressA5']){
 const args=['packages/protocol-v3/formal/settlement-replacement-retirement-mutations/run-check.mjs','node_modules/.bin/quint','verify','packages/protocol-v3/formal/settlement-replacement-retirement-exhaustive.qnt','--main',main,'--backend','tlc','--apalache-version','0.56.1','--server-endpoint','localhost:8845','--tlc-config',dir+'/tlc.json','--invariants','indContract',...(main.includes('Progress')?['allInvariants','contractInvariants']:[]),'--verbosity=3'];
 const output=[],log=dir+'/'+main+'.log',start=Date.now();
 const child=spawn('node',args,{env:{...process.env,JAVA_HOME:'/opt/homebrew/opt/openjdk@17',PATH:'/opt/homebrew/opt/openjdk@17/bin:'+process.env.PATH,JVM_ARGS:'-Xmx2g',TRACK_J_TIMEOUT_SECONDS:'900'}});
 for(const stream of [child.stdout,child.stderr])stream.on('data',b=>{output.push(b);writeFileSync(log,Buffer.concat(output));});
 const code=await new Promise(resolve=>child.on('close',resolve));const body=readFileSync(log,'utf8');
 const got=code===0&&/^\[ok\]/m.test(body)?'ok':code===1&&/^\[violation\]/m.test(body)?'violation':code===124?'timeout':'error';
 console.log(JSON.stringify({main,code,got,seconds:Math.round((Date.now()-start)/1000),log}));
}
