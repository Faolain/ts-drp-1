import base from "/Users/aristotle/Documents/Projects/ts-drp-1/vite.config.mts";
const control = process.env.CONTINUED_PLAY_CONTROL;
if (!["timer-block", "one-receiver"].includes(control)) throw new Error("CONTROL_REQUIRED");
export default {
 ...base,
 root: "/Users/aristotle/Documents/Projects/ts-drp-1",
 cacheDir: "/private/tmp/continued-play-starvation-negative-cache",
 plugins: [...base.plugins, {
  name: "continued-play-behavioral-negative",
  enforce: "pre",
  transform(code, id) {
   if (!id.endsWith("/tests/active-app-continued-play-native.test.ts")) return;
   let needle, replacement;
   if (control === "timer-block") {
    needle = "await step(name, () => sleep(ms));";
    replacement = 'await step(name, () => { if (name === "baseline-start") Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 1200); return sleep(ms); });';
   } else {
    needle = 'const window = {';
    replacement = 'if (name === "baseline-start") { const target = required(peers[1]).peerId; const originalSend = network.raw.send.bind(network.raw); network.raw.send = (sender, routeId, targets, bytes) => originalSend(sender, routeId, targets.filter(peer => peer !== target), bytes); }\n' + needle;
   }
   if (code.split(needle).length !== 2) throw new Error("CONTROL_DID_NOT_APPLY_EXACTLY_ONCE");
   return code.replace(needle, replacement).replace('kind: "configuration",', 'kind: "configuration", faultControl: '+JSON.stringify(control)+',');
  }
 }],
 test: {...base.test, root: "/Users/aristotle/Documents/Projects/ts-drp-1", name: "starvation-negative", globalSetup: ["/Users/aristotle/Documents/Projects/ts-drp-1"+"/scripts/check-shadowed-sources.mjs"], coverage: {...base.test.coverage, enabled: false}}
};
