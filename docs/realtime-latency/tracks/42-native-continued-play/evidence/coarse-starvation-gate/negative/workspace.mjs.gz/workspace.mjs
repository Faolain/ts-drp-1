export default ["/private/tmp/continued-play-starvation-negative.config.mts"];
