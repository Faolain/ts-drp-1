export default [new URL("./vitest.config.ts", import.meta.url).pathname];
