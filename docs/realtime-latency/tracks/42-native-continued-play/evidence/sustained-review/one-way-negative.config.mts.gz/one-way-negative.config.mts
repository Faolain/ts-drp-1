import base from "/Users/aristotle/Documents/Projects/ts-drp-1/vite.config.mts";
export default {
 ...base,
 root: "/Users/aristotle/Documents/Projects/ts-drp-1",
 cacheDir: "/private/tmp/continued-play-bounded-direction-cache",
 plugins: [...base.plugins, {
  name: "negative-control-drop-one-receiver-after-transition",
  enforce: "pre",
  transform(code, id) {
   if (!id.endsWith("/tests/active-app-continued-play-native.test.ts")) return;
   const needle = "channel.subscribe((frame) => {";
   if (!code.includes(needle)) throw new Error("one-way negative control did not apply");
   return code.replace(needle, needle + '\nif (index === 1 && phase === "baseline-after-1") return;');
  }
 }],
 test: {...base.test, root: "/Users/aristotle/Documents/Projects/ts-drp-1", name: "bounded-negative", globalSetup: ["/Users/aristotle/Documents/Projects/ts-drp-1/scripts/check-shadowed-sources.mjs"], coverage: {...base.test.coverage, enabled: false}}
};
